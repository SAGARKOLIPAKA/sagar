﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DATAOWNER_owner : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("upload.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("viewrequest.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("assignkey.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("mainhome.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}
