﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;

public partial class upload : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            file_id();
        }
    }

    public void file_id()
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select count(*)+1 from uploadfiles";

        cmd.Connection = con;
        SqlDataReader sdr;
        sdr = cmd.ExecuteReader();
        if (sdr.Read())
        {
            Label1.Text = sdr[0].ToString();
            

        }
        con.Close();
    
    
    }

    protected void Button6_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        string filename = Path.GetFileName(Fileupload.PostedFile.FileName);

    //save files to disk
        Fileupload.SaveAs(Server.MapPath("../files/" + filename));
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into uploadfiles(File_ID,File_Name,Keyword1,Keyword2,Choose_File)values(@File_ID,@File_Name,@Keyword1,@Keyword2,@Choose_File)";
        cmd.Parameters.AddWithValue("@File_ID", Label1.Text);
        cmd.Parameters.AddWithValue("@File_Name",TextBox2.Text);
        cmd.Parameters.AddWithValue("@Keyword1",TextBox3.Text);
        cmd.Parameters.AddWithValue("@Keyword2",TextBox4.Text);
        cmd.Parameters.AddWithValue("@Choose_File", filename);
       
       cmd.Connection = con;

        int i = cmd.ExecuteNonQuery();
        if (i > 0)
        {
            Label2.Text ="FIle Uploaded Successfully";

        }
    }
}