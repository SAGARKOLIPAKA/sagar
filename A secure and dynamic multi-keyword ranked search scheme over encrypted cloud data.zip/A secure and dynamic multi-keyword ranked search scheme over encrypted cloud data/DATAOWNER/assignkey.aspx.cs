﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class DATAOWNER_assignkey : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            bind();
        }
      //  string name = Session["username"].ToString();

    }
    protected void Button6_Click(object sender, EventArgs e)
    {
         
    
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

      
    }
    public void getusers()
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from uploadfiles where File_Name='" + DropDownList2.SelectedItem.Text + "'";

        cmd.Connection = con;
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter();
        da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
        con.Close();
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select File_Name from uploadfiles";
        cmd.Connection = con;
        SqlDataReader sdr;
        sdr = cmd.ExecuteReader();
        DropDownList2.Items.Insert(0, "--select--");
        while (sdr.Read())
        {
            DropDownList2.Items.Add(sdr["File_Name"].ToString());
        }

    }
    
protected void  GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

   

}
protected void Button7_Click(object sender, EventArgs e)
{
    SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
    con.Open();
    SqlCommand cmd = new SqlCommand();
    cmd.CommandType = CommandType.Text;
    cmd.CommandText = "update  uploadfiles set SecretKey='"+TextBox1.Text+"'  where File_Name='" + DropDownList2.SelectedItem.Text + "'";

    cmd.Connection = con;
    int i = cmd.ExecuteNonQuery();
    if(i>0)
    {
        
    }
}
}