﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class DATAOWNER_viewrequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            GetRequest();
        }
    }
    SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");

    public void GetRequest()

     {

         con.Open();
         SqlCommand cmd = new SqlCommand();
         cmd.CommandType = CommandType.Text;
         cmd.CommandText = "select fname from filerequest";

         cmd.Connection = con;
         SqlDataReader sdr;
         sdr = cmd.ExecuteReader();
         if (sdr.Read())
         {
            DropDownList1.Items.Add(sdr["fname"].ToString());


         }
         con.Close();
    
    }

    protected void Button6_Click(object sender, EventArgs e)
    {
       
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from  where fname='"+DropDownList1.SelectedItem.Text+"'";

        cmd.Connection = con;
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter();
        da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
        con.Close();
    
    }
}