﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class USER_download : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            bind();
        }

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("filedetails.aspx");

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
    
    }
         public void bind()
      {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select File_Name from uploadfiles";
        cmd.Connection = con;
        SqlDataReader sdr;
        sdr = cmd.ExecuteReader();
        DropDownList1.Items.Insert(0, "--select--");
        while (sdr.Read())
        {
            DropDownList1.Items.Add(sdr["File_Name"].ToString());
        }

         }
         protected void TextBox2_TextChanged(object sender, EventArgs e)
         {

         }
         protected void Button6_Click(object sender, EventArgs e)
         {

         }
}
    

  