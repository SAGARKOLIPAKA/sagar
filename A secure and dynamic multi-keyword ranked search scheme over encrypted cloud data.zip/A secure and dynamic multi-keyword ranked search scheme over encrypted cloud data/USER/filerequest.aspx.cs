﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class USER_filerequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           bind();
        }
        string name = Session["username"].ToString();
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select File_Name from uploadfiles";
        cmd.Connection = con;
        SqlDataReader sdr;
        sdr = cmd.ExecuteReader();
        DropDownList1.Items.Insert(0, "--select--");
        while (sdr.Read())
        {
            DropDownList1.Items.Add(sdr["File_Name"].ToString());
        }


    }




    protected void Button6_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "getrequest";
        cmd.Parameters.AddWithValue("@fname", DropDownList1.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@username", Session["username"].ToString());
        cmd.Connection = con;

        int i = cmd.ExecuteNonQuery();
        if (i > 0)
        {
            Label1.Text = "File Requested Successfull";

        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}


    