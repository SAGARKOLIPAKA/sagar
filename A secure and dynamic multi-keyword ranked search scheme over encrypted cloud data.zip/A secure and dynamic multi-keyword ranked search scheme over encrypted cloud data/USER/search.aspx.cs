﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class USER_search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        if (RadioButtonList1.SelectedItem.Text == "Filename Search")
        {
            cmd.CommandText = "select * from uploadfiles where File_Name=@file";
        }
        else if (RadioButtonList1.SelectedItem.Text =="Ranked Search")
        {
            cmd.CommandText = "select * from filerequest where count+1=@file";
        }
       
        else if (RadioButtonList1.SelectedItem.Text =="Keyword Search")
        {
            cmd.CommandText = "select * from uploadfiles where Keyword1=@file";
        }
        cmd.Parameters.AddWithValue("@file",TextBox1.Text);
        cmd.Connection = con;
        DataSet ds = new DataSet();
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        sda.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}