﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class CLOUDSERVER_filehacker : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from hacker";
        cmd.Connection = con;
        DataSet ds = new DataSet();
        SqlDataAdapter sdr = new SqlDataAdapter(cmd);
        sdr.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();

    }
}