﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class CLOUDSERVER_filedetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select File_Name from uploadfiles";
        cmd.Connection = con;
        SqlDataReader sdr;
        sdr = cmd.ExecuteReader();
        DropDownList1.Items.Insert(0, "--select--");
        while (sdr.Read())
        {
            DropDownList1.Items.Add(sdr["File_Name"].ToString());
        }


    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        
     SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from uploadfiles where File_Name='"+DropDownList1.SelectedItem.Text+"'";

        cmd.Connection = con;
        DataSet ds = new DataSet();
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        sda.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    
    
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
   