﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class REGISTER : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if(!IsPostBack)
        {
            uid();
        
        }
    }


    public void uid()
    {

        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select count(*)+1,getdate() from registration ";
       
        cmd.Connection = con;
        SqlDataReader sdr;
        sdr = cmd.ExecuteReader();
        if (sdr.Read())
        {
            Label1.Text = sdr[0].ToString();
            Label2.Text = sdr[1].ToString();
               
        }
        con.Close();
    
    }

  
   
    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("forgot.aspx");

    }
    protected void Button6_Click1(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("data source=.;database=securedynamic;integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into registration(uid,regdate,name,mobile,email,city,username,password)values(@uid,@regdate,@name,@mobile,@email,@city,@username,@password)";
        cmd.Parameters.AddWithValue("@uid", Label1.Text);
        cmd.Parameters.AddWithValue("@regdate", Label2.Text);
        cmd.Parameters.AddWithValue("@name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@mobile", TextBox2.Text);
        cmd.Parameters.AddWithValue("@email", TextBox3.Text);
        cmd.Parameters.AddWithValue("@city", TextBox4.Text);
        cmd.Parameters.AddWithValue("@username", TextBox5.Text);
        cmd.Parameters.AddWithValue("@password", TextBox6.Text);

        cmd.Connection = con;

        int i = cmd.ExecuteNonQuery();
        if (i > 0)
        {
            Label3.Text = "Registration Successfully Completed";

        }
    }
}