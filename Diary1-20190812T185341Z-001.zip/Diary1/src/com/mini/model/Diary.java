package com.mini.model;

public class Diary  {
	
	
	private String date;
	private String title;
	private String content;
	
	
	public Diary()
	{
	
	}
	
	public Diary(String date, String title, String content) {
		super();
		this.date = date;
		this.title = title;
		this.content = content;
	}

	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setConten(String content) {
		this.content = content;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((content == null) ? 0 : content.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Diary other = (Diary) obj;
		if (content == null) {
			if (other.content != null)
				return false;
		} else if (!content.equals(other.content))
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Diary [date=" + date + ", title=" + title + ", content=" + content + "]";
	}

	public int compareTo(String arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int compare(String arg0, String arg1) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	

}
