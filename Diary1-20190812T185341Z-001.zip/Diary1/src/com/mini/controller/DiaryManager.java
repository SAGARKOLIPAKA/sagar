package com.mini.controller;

import java.util.ArrayList;

import com.mini.model.Diary;

public class DiaryManager {
	private Diary diary;
	private ArrayList<Diary> allDiaries;
	private boolean status=false;
	
	
	public DiaryManager()
	{
		allDiaries=new ArrayList<>();
		diary=new Diary();
	}
	
	public boolean addDiary(Diary diary) {
		
		status=allDiaries.add(diary);
		return status;
	}
	
	public boolean removeDiary(Diary diary) {
		status=allDiaries.remove(diary);
		return status;
	}
	
	public ArrayList<Diary> getAllDiaries(){
		
		return allDiaries;
	}
}
