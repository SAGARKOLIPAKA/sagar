package com.mini.view;

import javax.swing.JFrame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;
import com.mini.controller.DiaryManager;
import com.mini.model.Diary;
import javax.swing.JPanel;

public class DiaryUI extends JFrame implements ActionListener{
	private Diary diary;
	private DiaryManager diaryManager;
	private ArrayList<Diary> allDiaries;
	private String date,content,title;
	JLabel lblDate,lblTitle,lblContent;
	JButton btnAddDiary,btnDisplay;
	JTextField txtDate,txtTitle,txtContent;
	JList<String> allTitle;
	DefaultListModel<String> data;
	JPanel pnlDiary;
	
	public DiaryUI() {
		super("MY DIARY");
		init();
		
		setSize(600,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	private void init()
	{
		lblContent=new JLabel("Description");
		lblDate=new JLabel("Date");
		lblTitle=new JLabel("Title");
		pnlDiary=new JPanel();
		btnDisplay=new JButton("All Diaries");
		btnAddDiary=new JButton("Add");
		txtDate=new JTextField(50);
		txtTitle=new JTextField(50);
		txtContent=new JTextField(50);
		allTitle=new JList<>();
		data=new DefaultListModel<>();
		allDiaries=new ArrayList<>();
		diaryManager=new DiaryManager();
		allDiaries=diaryManager.getAllDiaries();
		
		for(Diary diary:allDiaries) {
			data.addElement(diary.getTitle());
		}
		
		allTitle.setModel(data);
		
		
		pnlDiary.add(lblDate);
		pnlDiary.add(txtDate);
		pnlDiary.add(lblTitle);
		pnlDiary.add(txtTitle);
		pnlDiary.add(lblContent);
		pnlDiary.add(txtContent);
		pnlDiary.add(btnAddDiary);
		pnlDiary.add(btnDisplay);
		btnAddDiary.addActionListener(this);
		btnDisplay.addActionListener(this);
		
		
		add(pnlDiary);
		
	}
	private void clearFields() {
		
		txtContent.setText("");
		txtDate.setText("");
		txtTitle.setText("");
	}
	@Override
	public void actionPerformed(ActionEvent event) {
		
		
		if(event.getSource()==btnAddDiary) {
			title=txtTitle.getText();
			date=txtDate.getText();
			content=txtContent.getText();
			
			diary=new Diary();
			diary.setConten(content);
			diary.setDate(date);
			diary.setTitle(title);
			
			diaryManager.addDiary(diary);
			clearFields();
			
		}
		
	}
}

	