package com.mini.view;

public class DailyStart {

	public static void main(String[] args) {
		new DiaryUI();
	}

}
